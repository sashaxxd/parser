<?php
echo $body;