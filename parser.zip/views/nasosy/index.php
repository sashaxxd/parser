<?php
echo 'Готово данные залиты в базу';

//foreach ($res as $item):?>
<?php
//    $item = pq($item );
//    $img = $item->attr('src');
//    $img = 'https://www.sklad-generator.ru' . $img;
//    Debug($img);
//?>
<!--<img src="--><?//= $img  ?><!--">-->
<?php //endforeach; ?>
<!---->
<?php
//
//echo Yii::getAlias('@webroot');

